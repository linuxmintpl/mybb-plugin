<?php
/**
 * Imgur.com plugin : allow to upload an image to imgur
 * and add it in the post
 */
 
$l['imgur_open'] = "New Imgur Pic";
$l['imgur_ptitle'] = "Upload to Imgur";
$l['imgur_select'] = "Select file...";