<?php
/**
 * Imgur.com plugin : allow to upload an image to imgur
 * and add it in the post
 */
 
$l['imgur_open'] = "Image Imgur";
$l['imgur_ptitle'] = "Uploader sur Imgur";
$l['imgur_select'] = "Choisir un fichier...";