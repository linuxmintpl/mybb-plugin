[jQuery] Appearing Scroll to Top (1.1)

Adds a scroll to top

Created by: Vintagedaddyo

Now with localization support for:

- english
- englishgb
- espanol
- french
- italiano

To Install:

Upload The File, And Go to Admin CP And Active IT!

Visit settings to turn settings on / off
