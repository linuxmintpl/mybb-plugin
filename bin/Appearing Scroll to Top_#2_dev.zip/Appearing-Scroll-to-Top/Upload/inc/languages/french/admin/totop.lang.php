<?php
/*
 * MyBB: [jQuery] Appearing Scroll to Top
 *
 * File: totop.lang.php
 * 
 * Authors: Vintagedaddyo, effone
 *
 * MyBB Version: 1.8
 *
 * Plugin Version: 1.1
 * 
 */

// plugin_info

$l['totop_Name'] = '[jQuery] Apparaissant Faites défiler vers le haut';
$l['totop_Desc'] = 'Ajoute un défilement vers le haut';
$l['totop_Web'] = 'http://community.mybb.com/user-6029.html';
$l['totop_Auth'] = 'Vintagedaddyo';
$l['totop_AuthSite'] = 'http://community.mybb.com/user-6029.html';
$l['totop_Ver'] = '1.1';
$l['totop_GUID'] = '';
$l['totop_Compat'] = '18*';

//
$l['totop_settings_Title'] = '[jQuery] Apparaissant Faites défiler vers le haut';
$l['totop_settings_Description'] = 'Paramètres pour [jQuery] Apparaissant Faites défiler vers le haut';

//
$l['totop_option_1_Title'] = 'Voulez-vous activer [jQuery] Apparaissant Faites défiler vers le haut Plugin?';
$l['totop_option_1_Description'] = 'Si vous définissez cette option sur yes, ce plugin sera actif sur votre forum.';

//
$l['totop_option_2_Title'] = 'Activer le plugin sur l index';
$l['totop_option_2_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_3_Title'] = 'Activer le plugin sur Forum Display';
$l['totop_option_3_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_4_Title'] = 'Activer le plugin sur Afficher le fil';
$l['totop_option_4_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_5_Title'] = 'Activer le plugin sur la liste des membres';
$l['totop_option_5_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_6_Title'] = 'Activer le plugin sur Member';
$l['totop_option_6_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_7_Title'] = 'Activer le plugin sur Misc';
$l['totop_option_7_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_8_Title'] = 'Activer le plugin sur Search';
$l['totop_option_8_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_9_Title'] = 'Activer le plugin sur ModCP';
$l['totop_option_9_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_10_Title'] = 'Activer le plugin sur UserCP';
$l['totop_option_10_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_11_Title'] = 'Activer le plugin sur Private';
$l['totop_option_11_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_12_Title'] = 'Activer le plugin sur le fil d impression';
$l['totop_option_12_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_13_Title'] = 'Activer le plugin sur le calendrier';
$l['totop_option_13_Description'] = 'Tourner le plugin (ON / OFF)';

//
$l['totop_option_14_Title'] = 'Activer le plugin sur Portal';
$l['totop_option_14_Description'] = 'Tourner le plugin (ON / OFF)';

?>