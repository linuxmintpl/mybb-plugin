<?php
/*
 * MyBB: [jQuery] Appearing Scroll to Top
 *
 * File: totop.lang.php
 * 
 * Authors: Vintagedaddyo, effone
 *
 * MyBB Version: 1.8
 *
 * Plugin Version: 1.1
 * 
 */

// plugin_info

$l['totop_Name'] = '[jQuery] Scorrere fino a inizio pagina';
$l['totop_Desc'] = 'Aggiunge una pergamena verso l alto';
$l['totop_Web'] = 'http://community.mybb.com/user-6029.html';
$l['totop_Auth'] = 'Vintagedaddyo';
$l['totop_AuthSite'] = 'http://community.mybb.com/user-6029.html';
$l['totop_Ver'] = '1.1';
$l['totop_GUID'] = '';
$l['totop_Compat'] = '18*';

//
$l['totop_settings_Title'] = '[jQuery] Scorrere fino a inizio pagina';
$l['totop_settings_Description'] = 'Impostazioni per [jQuery] Scorrere fino a inizio pagina';

//
$l['totop_option_1_Title'] = 'Vuoi abilitare [jQuery] Apparendo Scroll to Top Plugin?';
$l['totop_option_1_Description'] = 'Se imposti questa opzione su yes, questo plugin sarà attivo sulla tua bacheca.';

//
$l['totop_option_2_Title'] = 'Abilita plugin su Index';
$l['totop_option_2_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_3_Title'] = 'Abilita plugin su Forum Display';
$l['totop_option_3_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_4_Title'] = 'Abilita plugin su Mostra discussione';
$l['totop_option_4_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_5_Title'] = 'Abilita il plug-in su Memberlist';
$l['totop_option_5_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_6_Title'] = 'Abilita plugin su Member';
$l['totop_option_6_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_7_Title'] = 'Abilita plugin su Misc';
$l['totop_option_7_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_8_Title'] = 'Abilita il plug-in per la ricerca';
$l['totop_option_8_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_9_Title'] = 'Abilita plugin su ModCP';
$l['totop_option_9_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_10_Title'] = 'Abilita plugin su UserCP';
$l['totop_option_10_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_11_Title'] = 'Abilita plugin su Private';
$l['totop_option_11_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_12_Title'] = 'Abilita plugin su Print Thread';
$l['totop_option_12_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_13_Title'] = 'Abilita plugin su Calendar';
$l['totop_option_13_Description'] = 'Turn plug (ON / OFF)';

//
$l['totop_option_14_Title'] = 'Abilita plugin sul portale';
$l['totop_option_14_Description'] = 'Turn plug (ON / OFF)';

?>